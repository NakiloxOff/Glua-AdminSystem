local ply = LocalPlayer()
local enservice = false

surface.CreateFont( "admin_affichage_2d", {
	font = "Arial", 
	extended = false,
	size = ScreenScale(15),
	weight = 0,
} )

surface.CreateFont( "admin_affichage_3d", {
	font = "Arial", 
	extended = false,
	size = ScreenScale(10),
	weight = 0,
} )



hook.Add("OnPlayerChat", "AdminCommand", function(ply, text, team)
    if string.lower(text) == config.command then
        local ply_groupe = ply:GetUserGroup()
        local service = table.HasValue(config.groupes, ply_groupe)

        if service then

            if not enservice then 
                local CurT = CurTime()
                notification.AddLegacy( config.langage.enter_admin, NOTIFY_GENERIC, 5 )


                hook.Add("PostDrawTranslucentRenderables", "draw_admin_view", function()
                    local function informations_view(pos1,pos2, img, text) 
                        surface.SetMaterial(Material(img))
                        surface.DrawTexturedRect(pos1 - 60, pos2 - 10, 22, 22)
                        surface.SetDrawColor(Color(255, 255, 255))
                        draw.SimpleText(text, "admin_affichage_3d", pos1 - 30, pos2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                        local squareSize = 20
                        local widthtxt, heighttxt = surface.GetTextSize( text )
                        surface.DrawLine(pos1-65, pos2-14, pos1-20+widthtxt,pos2-14)
                        surface.DrawLine(pos1-65, pos2+16, pos1-20+widthtxt,pos2+16)
                        surface.DrawLine(pos1-65, pos2-14, pos1-65,pos2+16)
                        surface.DrawLine(pos1-35, pos2-14, pos1-35,pos2+16)
                        surface.DrawLine(pos1-20+widthtxt, pos2-14, pos1-20+widthtxt,pos2+16)
                    end

                    for _, plyall in pairs(player.GetAll()) do

                        local pos = plyall:GetPos() + Vector(0, 0, 82)
                        local screenPos = pos:ToScreen()
                        
                        cam.Start2D()
                        if ply:GetPos():Distance(plyall:GetPos()) >= 300 and plyall ~= ply then
                            draw.SimpleText("●", "admin_affichage_3d", screenPos.x, screenPos.y, plyall:getJobTable().color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                        elseif ply:GetPos():Distance(plyall:GetPos()) < 300 and plyall ~= ply then
                            informations_view(screenPos.x, screenPos.y, "iconesp/user.png", plyall:Nick()) 
                            informations_view(screenPos.x, screenPos.y+30, "iconesp/hp.png", plyall:Health()) 
                            informations_view(screenPos.x, screenPos.y+60, "iconesp/armur.png", plyall:Armor()) 
                            informations_view(screenPos.x, screenPos.y+90, "iconesp/money.png",plyall:getDarkRPVar("money").."$")
                        end

                        cam.End2D()
                        

                    end
                end)
                
                enservice = true 
            elseif enservice then
                hook.Remove("HUDPaint", "draw_admin_hud")
                hook.Add("PostDrawTranslucentRenderables", "draw_admin_view", function() end)
                notification.AddLegacy( config.langage.exit_admin, NOTIFY_GENERIC, 5 )
            enservice = false
            end

        else
            notification.AddLegacy( config.langage.noacces, NOTIFY_ERROR, 5 )
        end
        return true
    end
end)