--[[
Copyright 2024 NAKILOX

Permet au Modérateur/Administrateur de freeze avec le physigun et de voir les joueur sur la map.

Discord PulseTech : https://discord.gg/CMGb3xn2JF

]]

--Physigun 

nalib = {} 
nalib.AdminRank = {
    ["superadmin"] = true,  
    ["admin"] = true,
    ["modo"] = true
}

--Mode Administrateur
if CLIENT then
    config = {
        groupes = { 
            "superadmin", 
            "admin",
            "modo"
        },

        langage = {
            enter_admin = "Vous êtes passer en mode administrateur. ",
            exit_admin = "Vous avez quitté le mode administrateur.",
            noacces = "Vous n'êtes pas autorisé à entrer en mode administrateur.",
            service = "En Ligne",        },
        
        command =  "!staff"
    }

end