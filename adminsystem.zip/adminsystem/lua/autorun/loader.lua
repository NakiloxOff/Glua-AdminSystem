local folder = "nalib"


if SERVER then
    AddCSLuaFile(folder .. "/client/cl_physgun_rainbow.lua")
    AddCSLuaFile(folder .. "/client/cl_adminview.lua")
    AddCSLuaFile(folder .. "/config.lua")
    
    


    else



    include(folder .. "/client/cl_adminview.lua")
    include(folder .. "/client/cl_physgun_rainbow.lua")
    include(folder .. "/config.lua")


end